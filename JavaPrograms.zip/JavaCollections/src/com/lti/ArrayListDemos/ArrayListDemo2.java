package com.lti.ArrayListDemos;

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo2 {
	public static void main(String[] args) {
		
		Employee e1= new Employee(101,"Viru",50000.00f);
		Employee e2= new Employee(102,"Jay",60000.00f);
		Employee e3= new Employee(103,"Thakur",70000.00f);
		
		List myList=new ArrayList();
		
		myList.add(e1);
		myList.add(e2);
		myList.add(e3);
		
		System.out.println(myList);
		
		myList.remove(e2);
		
		System.out.println(myList);
		
		Book b1=new Book(1111,"Java");
		Book b2=new Book(1112,"Oracle");
		
		myList.add(b1);
		myList.add(b2);
		
		System.out.println(myList);
		
		myList.remove(0);
		
		System.out.println(myList);
		
		myList.add(e1);
		
		System.out.println(myList);
		
	}
}
