package com.lti.SetDemo;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import com.lti.ArrayListDemos.Book;

public class HashSetDemo {
	
	
	public static void main(String[] args) {
		Set mySet= new HashSet();
		
		
		/*mySet.add(300);
		mySet.add(100);
		mySet.add(200);
		mySet.add(100);
        mySet.add("Jay");
		mySet.add("VJay");		
		
		System.out.println(mySet);*/
		
		Book b1=new Book(1111,"Java");
		Book b2=new Book(1112,"Oracle");
		
		mySet.add(b1);
		mySet.add(b2);
		
		//System.out.println(mySet);
		
		System.out.println(b1.hashCode());
		
		System.out.println(b2.hashCode());
		
		Iterator it1 = mySet.iterator();
		
		while(it1.hasNext())
		{
			System.out.println(it1.next());
		}
	/*	Set tset= new TreeSet();
		
		tset.add(3000);
		tset.add(2000);
		tset.add(2500);
		tset.add("Jay");
		tset.add("VJay");	
		
		System.out.println(tset);*/
		
		
		
		
	//	System.out.println(mySet);	
	}
}
