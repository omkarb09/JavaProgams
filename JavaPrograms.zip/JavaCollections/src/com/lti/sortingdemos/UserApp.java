package com.lti.sortingdemos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UserApp 
{
	public static void main(String[] args) 
	{
		List<Employee> ar = new ArrayList<Employee>(); 
		Employee e1= new Employee(108,"Mario",50000.00f);
		Employee e2= new Employee(102,"Luigi",60000.00f);
		Employee e3= new Employee(111,"Peach",70000.00f);
		
		ar.add(e1);
		ar.add(e2);
		ar.add(e3);
		
		System.out.println("Before sort"+ar);
		
		Collections.sort(ar,new EmpSortById());
		
		System.out.println("After sort by id");
		for(Employee e:ar)
		{
			System.out.println(e);
		}
		
		System.out.println("After sort by sal");
		Collections.sort(ar,new EmpSortBySal());
		for(Employee e:ar)
		{
			System.out.println(e);
		}
		
		
		
		
	}
}
