package com.lti.sortingdemos;

import java.util.Comparator;

public class EmpSortBySal implements Comparator<Employee>
{

	@Override
	public int compare(Employee e1,Employee e2) {
		// TODO Auto-generated method stub
		if(e1.getEmpSal()>e2.getEmpSal())
		{
			return 1;
		}
		else
		{
			return -1;
		}
	}
}
