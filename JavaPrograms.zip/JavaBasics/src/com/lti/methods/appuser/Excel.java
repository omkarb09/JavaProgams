package com.lti.methods.appuser;

public class Excel {
  public int sum(int x,int y)
   {
	   int result =x+y;
	   return result;
   }
}
