package com.lti.methods.appuser;

public class User {
	public static void main(String[] args) {
		Excel ws1=new Excel();
		int res=ws1.sum(400, 4000);
		System.out.println("addition :"+res);
		
		
		
		
	}
}
