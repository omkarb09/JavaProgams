package com.lti.assignments;

public class VariableArg {
	public int sum(int ...res)
	{
		int total=0;
		for(int i:res)
		{
			System.out.println(i+" ");
			total=total+i;
		}
			
		return total;
	}
	
	public static void main(String[] args) {
		VariableArg obj= new VariableArg();
		
		int result=obj.sum(10,20,40,89,76);
		System.out.println("Total:"+result);
	}
	
}
