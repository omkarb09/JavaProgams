package com.lti.assignments;

public class Calc {
	public float cal(int unit)
	{
		float bill;
		if(unit<50)
		{
			bill=unit*2;
		}
		else
		{
			bill=unit*3.5f;
		}
		return bill;
	}
}
