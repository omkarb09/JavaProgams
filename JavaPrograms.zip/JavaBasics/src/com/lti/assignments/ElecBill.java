package com.lti.assignments;

import java.util.Scanner;

public class ElecBill {
	public static void main(String[] args) {
		
		int meterno;
		int prev_reading;
		int curr_reading;
		float bill;
		
		Scanner sc=new Scanner(System.in);
		byte ch;
		do{
			System.out.println("Electricity bill\n1.Calculate Bill\n2.Exit\nEnter your choice:");
			ch=sc.nextByte();
			
			switch(ch)
			{
				case 1:
					System.out.println("Enter meterno: ");
					meterno=sc.nextInt();
					
					System.out.println("Enter prev_reading: ");
					prev_reading=sc.nextInt();
					
					System.out.println("Enter curr_reading: ");
					curr_reading=sc.nextInt();
					
					Calc obj = new Calc();
					bill=obj.cal((curr_reading-prev_reading));
					
					System.out.println("Bill amount: "+bill);
				break;
				
				case 2:
					break;
					
				default:
					System.out.println("Invalid choice");
			}
			System.out.println("\n");
		}while(ch!=2);
		
	}
}
