package com.lti.assignments;

import java.util.Scanner;

public class Student {
	public static void main(String[] args) {
		int id=0;
		String name;
		int marks=0;
		int fees=0;
		String grade;
		Scanner sc=new Scanner(System.in);
		byte ch;
		do{
			System.out.println("Grade measure\n1.Calculate grade\n2.Exit\nEnter your choice:");
			ch=sc.nextByte();
			
			switch(ch)
			{
				case 1:
					System.out.println("Enter student id: ");
					id=sc.nextInt();
					
					System.out.println("Enter name: ");
					name=sc.next();
					
					System.out.println("Enter marks: ");
					marks=sc.nextInt();
					
					System.out.println("Enter fees: ");
					fees=sc.nextInt();
					
					if(marks>=80 && marks<=100)
						grade="A";
					
					else if(marks>=60 && marks<=80)
						grade="B";

					else if(marks>=50 && marks<=60)
						grade="C";
					
					else
						grade="Fail";
					
					System.out.println("Id: "+id+"\nName: "+name+"\nGrade: "+grade+"\nFees: "+fees);
				break;
				
				case 2:
					break;
					
				default:
					System.out.println("Invalid choice");
			}
			System.out.println("\n");
		}while(ch!=2);
		
	}
}
