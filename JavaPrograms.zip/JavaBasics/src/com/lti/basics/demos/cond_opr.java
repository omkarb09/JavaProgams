package com.lti.basics.demos;

import java.util.Scanner;

public class cond_opr {
	public static void main(String[] args) {
		
		/*int age=78;
		String ans;
		ans=(age>18)?"You can vote":"You cant vote";
		System.out.println(ans);*/
		
		Scanner input = new Scanner(System.in); 
        int a, b, c, d;
        a = input.nextInt();
        b = input.nextInt();
        c = input.nextInt();
        d = (a > b) ? ((a > c) ? a : c) : ((b > c) ? b : c);
        System.out.println("Greater number is :" + d);
	}
}
