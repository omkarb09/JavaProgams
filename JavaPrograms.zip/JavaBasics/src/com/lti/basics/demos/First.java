package com.lti.basics.demos;

import java.util.Scanner;

public class First {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Simple addition program");
		
		/*int x,y,res;
		System.out.println("Enter first number : ");
		x=sc.nextInt();
		System.out.println("Enter second number : ");
		y=sc.nextInt();
		res=x+y;
		System.out.println("Addition of "+x+" and "+y+" is "+res);*/
		
		int x = 10;
		if(x==5)
		{
			System.out.println("x is 5");
			System.out.println("inside if");
		}
		
		else
		{
			System.out.println("x is 10");
			System.out.println("inside else");
		}
		
	}
}
