package com.lti.basics.demos;

import java.util.Scanner;

public class ArrayDemo {
	public static void main(String[] args) {
		
		/*int[] marks= {90,80,75,88,99};
		
		for(int i=0;i<5;i++)
		{
			System.out.println(marks[i]);
		}*/
		Scanner sc= new Scanner(System.in);
		
		int[] marks = new int[5];
		
		for(int i=0;i<5;i++)
		{
			System.out.println("Enter marks : ");
			marks[i]=sc.nextInt();
		}
		
		System.out.println("Marks are as follows : ");
		
		for(int i=0;i<5;i++)
		{
			System.out.println(marks[i]);
		}
		
		int total=0;
		
		for(int i=0;i<5;i++)
		{
			total=total+marks[i];
		}
		System.out.println("Total : "+total);
		System.out.println("Average : "+total/5);
	}
}
