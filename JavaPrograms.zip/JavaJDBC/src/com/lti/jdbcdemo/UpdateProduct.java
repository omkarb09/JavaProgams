package com.lti.jdbcdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateProduct {
	public static void main(String[] args)throws SQLException {
		Scanner sc=new Scanner(System.in);
		
		String url = "jdbc:oracle:thin:scott@//localhost:1521/XE";
		 
		 Connection  conn=DriverManager.getConnection(url,"hr","hr");
		PreparedStatement pstmt;
		 
		 if (conn != null) 
		 {
			    System.out.println("Connected");
		 }
		 
		 	
		 	
		 try 
		 {
		 	pstmt=conn.prepareStatement("Update Products set prdname=?,prdcost=? where prdid=?");
		 	System.out.println("Enter product id:");
		 	int pid=sc.nextInt();
		 	
		 	System.out.println("Enter product name:");
		 	String pname=sc.next();
		 	
		 	System.out.println("Enter product cost:");
		 	double pcost=sc.nextDouble();
		 	pstmt.setString(1, pname);;
		 	pstmt.setDouble(2,pcost);
		 	pstmt.setInt(3, pid);
		 	
		 	int i=pstmt.executeUpdate();
		 	System.out.println(i+" record updated");
		 	
		} 
		catch (SQLException e) 
		{
				System.out.println(e.getMessage());
		}
		 finally
		 {
			 conn.close();
		 }
	}
}
