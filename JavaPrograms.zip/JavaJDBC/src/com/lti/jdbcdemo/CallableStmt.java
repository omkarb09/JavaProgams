package com.lti.jdbcdemo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class CallableStmt {
public static void main(String[] args) throws SQLException {
		
		String url = "jdbc:oracle:thin:@localhost:1521/XE";	// orcl or XE 
				Connection  conn=DriverManager.getConnection(url,"hr","hr");
			
			Statement stmt = null;
			 PreparedStatement pstmt=null;
			 if (conn != null) 
			 {
				    System.out.println("Connected");
			 }
			 try
			 {
				 	CallableStatement cstmt1=conn.prepareCall("call getProductName(?,?)");
				 	cstmt1.setInt(1, 5454);
				 	cstmt1.registerOutParameter(2, java.sql.Types.VARCHAR);
				 	cstmt1.executeUpdate();
				 	String userName=cstmt1.getString(2);
				 	System.out.println(userName);
			 }
			 catch(SQLException e)
			 {
				 System.out.println(e.getMessage());
			 }
			 finally
				{
					try
					{	
					conn.close();}
					catch(Exception e)
					{System.out.println(e);}
				}		
	}
}

