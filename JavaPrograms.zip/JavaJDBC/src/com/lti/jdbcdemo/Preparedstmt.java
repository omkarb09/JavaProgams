package com.lti.jdbcdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Preparedstmt {
	public static void main(String[] args)throws SQLException {
		Scanner sc=new Scanner(System.in);
		
		String url = "jdbc:oracle:thin:scott@//localhost:1521/XE";
		 
		Connection  conn=DriverManager.getConnection(url,"hr","hr");
		PreparedStatement pstmt;
		 
		 if (conn != null) 
		 {
			    System.out.println("Connected");
		 }
		 
		 	
		 	
		 try 
		 {
		 	pstmt=conn.prepareStatement("Insert into Products values(?,?,?)");
		 	int pid=sc.nextInt();
		 	pstmt.setInt(1, pid);;
		 	pstmt.setString(2,"charger");
		 	pstmt.setFloat(3, 1000);
		 	
		 	int i=pstmt.executeUpdate();
		 	System.out.println(i+"record added");
		 	
		} 
		catch (SQLException e) 
		{
				System.out.println(e.getMessage());
		}
		 finally
		 {
			 conn.close();
		 }
	}
}
