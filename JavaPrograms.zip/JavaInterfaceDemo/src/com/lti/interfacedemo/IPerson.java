package com.lti.interfacedemo;

public interface IPerson {
	public void calc();
}
