package com.lti.interfacedemo;

public class TestInterface {
	public static void main(String[] args) {
		
		//permanent object employee
		PermEmpImp1 pemp = new PermEmpImp1();
		
		pemp.setEmpId(1234);
		pemp.setBasicSal(10000);
		
		pemp.calc();
		
		//************************************
		
		//temporary object employee
		TempEmpImp1 temp = new TempEmpImp1();
		
		temp.setTempId(4545);
		temp.setNoDays(20);
		temp.setSalPerDay(500.00f);
		
		temp.calc();
		IPerson p;
		p=pemp;
		p.calc();
		
		p=temp;
		p.calc();
	}
}
