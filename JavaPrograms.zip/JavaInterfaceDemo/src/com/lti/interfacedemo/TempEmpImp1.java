package com.lti.interfacedemo;

public class TempEmpImp1 implements IPerson
{
	int tempId;
	double salPerDay;
	int noDays;
	
	@Override
	public void calc() {
		double tSal=salPerDay*noDays;
		System.out.println("Temp Employee total sal "+tSal);
	}

	
	@Override
	public String toString() {
		return "TempEmpImp1 [tempId=" + tempId + ", salPerDay=" + salPerDay + ", noDays=" + noDays + "]";
	}



	public int getTempId() {
		return tempId;
	}

	public void setTempId(int tempId) {
		this.tempId = tempId;
	}

	public double getSalPerDay() {
		return salPerDay;
	}

	public void setSalPerDay(double salPerDay) {
		this.salPerDay = salPerDay;
	}

	public int getNoDays() {
		return noDays;
	}

	public void setNoDays(int noDays) {
		this.noDays = noDays;
	}
	
	
	
	
}
