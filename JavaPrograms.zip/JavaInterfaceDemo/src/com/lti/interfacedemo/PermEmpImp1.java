package com.lti.interfacedemo;

public class PermEmpImp1 implements IPerson
{
	int empId;
	double basicSal;
	
	public void calc() 
	{
		double tSal=basicSal+1000;
		System.out.println("PermEmployee Total sal\t"+tSal);
	}

	
	@Override
	public String toString() {
		return "PermEmpImp1 [empId=" + empId + ", basicSal=" + basicSal + "]";
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public double getBasicSal() {
		return basicSal;
	}

	public void setBasicSal(double basicSal) {
		this.basicSal = basicSal;
	}
	

}
