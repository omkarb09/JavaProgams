package com.lti.assignment.user;

import java.util.Scanner;

import com.lti.assignment.entity.SavingAccount;


public class User {
	public static void main(String[] args) 
	{
		//SavingAccount obj = new SavingAccount(3146,"Spiderman",800);
		//System.out.println(obj);
		Scanner sc=new Scanner(System.in);
		//obj.withdraw(600);
		//obj.deposit(5000);
		
		
		
		
		System.out.println("Enter account number:");
		int accId=sc.nextInt();
		System.out.println("Enter account name:");
		String accName=sc.next();
		System.out.println("Enter account balance:");
		double accBal=sc.nextDouble();
		SavingAccount obj = new SavingAccount(accId,accName,accBal);
		System.out.println(obj);
		
		System.out.println("\nEnter amount to withdraw:");
		obj.withdraw(sc.nextDouble());
		System.out.println("\nEnter amount to deposit:");
		obj.deposit(sc.nextDouble());
		
	}
}
