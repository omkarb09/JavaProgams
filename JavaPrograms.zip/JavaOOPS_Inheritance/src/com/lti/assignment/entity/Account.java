package com.lti.assignment.entity;

public class Account 
{
	protected static String bankname="Apna Bank";
	protected int accId;
	protected String accName;
	protected double balAmt;
	
}

