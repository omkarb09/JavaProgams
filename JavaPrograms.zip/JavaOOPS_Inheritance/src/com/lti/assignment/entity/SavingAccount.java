package com.lti.assignment.entity;

public class SavingAccount extends Account
{
	static private double minBal=200;
	
	public SavingAccount() 
	{
		
	}
	
	public SavingAccount(int accId,String accName,double balAmt) 
	{
		this.accId=accId;
		this.accName=accName;
		this.balAmt=balAmt;
	}

	public void withdraw(double wamt)
	{
		//balAmt=balAmt-wamt;
		double temp=balAmt;
		if((temp=temp-wamt)<minBal)
		{
			System.out.println("\nCannot witdraw, Insufficient balance");
		}
		else
		{
			balAmt=balAmt-wamt;
			System.out.println("\nCurrent Balance after withdrawing:"+balAmt);
		}
		
	}
	
	public void deposit(double wamt)
	{
		balAmt=balAmt+wamt;
		System.out.println("\nCurrent Balance after depositing:"+balAmt);
	}

	@Override
	public String toString() {
		return ("Account details :\nBank name:"+bankname+"\nminBal:" + minBal + "\naccId:" + accId + "\naccName:" + accName + "\nbalAmt:" + balAmt);
	}
	
	
}
