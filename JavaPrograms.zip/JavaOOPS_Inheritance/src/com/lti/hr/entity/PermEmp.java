package com.lti.hr.entity;

public class PermEmp extends Person {
int basicSal;


public PermEmp() {
	super();
	// TODO Auto-generated constructor stub
}
public PermEmp(int id, String name,int basicSal) {
	//super(id, name);
	this.id=id;
	this.name=name;
	this.basicSal=basicSal;
	// TODO Auto-generated constructor stub
}
public void calcSal(){
	System.out.println(basicSal+5000);
}

public int getBasicSal() {
	return basicSal;
}
public void setBasicSal(int basicSal) {
	this.basicSal = basicSal;
}

@Override
public String toString() {
	return "PermEmp [basicSal=" + basicSal + ", id=" + id + ", name=" + name + "]";
}






}



