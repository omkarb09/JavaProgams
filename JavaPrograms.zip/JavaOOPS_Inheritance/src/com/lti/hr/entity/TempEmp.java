package com.lti.hr.entity;

public class TempEmp extends Person {
     int noDays;
     int perDaySal;
     
	public TempEmp() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public TempEmp(int id, String name,int noDay,int perDaySal) {
		//super(id, name);
		this.id=id;
		this.name=name;
		this.noDays=noDay;
		this.perDaySal=perDaySal;
	}
	
	public void calcSal(){
		int tSal=noDays*perDaySal;
		System.out.println(tSal);
		
	}

	@Override
	public String toString() {
		return "TempEmp [noDays=" + noDays + ", perDaySal=" + perDaySal + ", id=" + id + ", name=" + name + "]";
	}
     
	
     
}
