package com.lti.hr.user;
import com.lti.hr.entity.PermEmp;
import com.lti.hr.entity.Person;
import com.lti.hr.entity.TempEmp;

//import com.lti.hr.entity.Person;

public class MyUserApp {
	
	public static void main(String[] args) {
/*		Person p1=new Person(1000,"ABC");
		System.out.println(p1);
		p1.calcSal();*/
		
		/*PermEmp pe=new PermEmp();
		pe.setId(101);
		pe.setName("jay");
		pe.setBasicSal(5000);
		System.out.println(pe);
		pe.calcSal();*/
		
		/*PermEmp pe1=new PermEmp(102,"Vijay",6000);
		System.out.println(pe1);*/
		
		TempEmp te1=new TempEmp(102,"Vijay",10,6000);
		System.out.println(te1);
		te1.calcSal();
		
	}
}
