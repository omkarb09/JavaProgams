package com.lti.shopping.user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.lti.shopping.dao.IDaoProduct;
import com.lti.shopping.dao.ImplDaoProduct;
import com.lti.shopping.entity.Product;



public class ClientApp {
	public static void main(String[] args) 
	{
		
		ArrayList mylist=new ArrayList();
		IDaoProduct service= new ImplDaoProduct();
		Scanner sc = new Scanner(System.in);
		String ans;
		int no;
		do {
			System.out.println("***** DMART Products Services ****");
			System.out.println("1.Add product ");
			System.out.println("2.Display all product ");
			System.out.println("3.Search product by id");
			System.out.println("Pls enter your choice: ");
			no = sc.nextInt();

			switch (no) 
			{
				case 1:
					System.out.println("Enter details of Product");
					Product p = new Product(sc.nextInt(),sc.next(),sc.nextFloat());
					service.addProducts(p);	
					break;
				case 2: System.out.println("case 2");
						mylist=service.getAllProducts();
						Iterator it1 = mylist.iterator();
						
						while(it1.hasNext())
						{
							System.out.println(it1.next());
						}
						break;
				case 3:
					System.out.println("Enter Product id");	
					Product temp=service.searchProduct(sc.nextInt());
					System.out.println(temp);
					break;
				default:System.out.println("Enter proper choice");
						break;
			}
			System.out.println("Do you want to continue yes/no");
			ans = sc.next();
		} while (ans.equals("Yes") || ans.equals("y") || ans.equals("yes"));
	}
}
