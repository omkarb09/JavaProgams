package com.lti.shopping.dao;

import java.util.ArrayList;

import com.lti.shopping.entity.Product;

public interface IDaoProduct 
{
	
	public abstract void addProducts(Product p);
	public abstract ArrayList<Product> getAllProducts();
	
	public abstract Product searchProduct(int id);
}
