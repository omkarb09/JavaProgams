package com.lti.shopping.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lti.shopping.entity.Product;

public class ImplDaoProduct implements IDaoProduct
{

	
	public void addProducts(Product p) 
	{
		System.out.println("calling addProduct ...... inside dao");
		System.out.println(p);
		
			
		 try 
		 {
			String url = "jdbc:oracle:thin:scott@//localhost:1521/XE";
			 
			Connection conn=DriverManager.getConnection(url,"hr","hr");
			PreparedStatement pstmt;
			if (conn != null) 
			{
				   System.out.println("Connected\n");
			}
			pstmt=conn.prepareStatement("Insert into Products values(?,?,?)");
		 	
		 	pstmt.setInt(1, p.getPrdId());;
		 	pstmt.setString(2,p.getPrdName());
		 	pstmt.setFloat(3, p.getPrdCost());
		 	
		 	int i=pstmt.executeUpdate();
		 	System.out.println(i+" record added");
		 	conn.close();
		 	
		} 
		catch (SQLException e) 
		{
				System.out.println(e.getMessage());
		}
		
		
	}

	@Override
	public ArrayList<Product> getAllProducts() {
		 
		ArrayList<Product> mylist = new ArrayList<>();
		 try 
		 {
			 String url = "jdbc:oracle:thin:scott@//localhost:1521/XE";
			 
			 Connection  conn=DriverManager.getConnection(url,"hr","hr");
			
			 if (conn != null) 
			 {
				    System.out.println("Connected\n");
			 }
			 
			 Statement stmt=conn.createStatement();
			
			ResultSet rs=stmt.executeQuery("select prdid,prdname,prdcost from Products");
			 	
			while(rs.next())
			{
			 	Product p=new Product(rs.getInt(1),rs.getString(2),rs.getFloat(3));
			 	mylist.add(p);
			}
			return mylist;
		} 
		catch (SQLException e) 
		{
				System.out.println(e.getMessage());
		}
		return mylist;
	}

	@Override
	public Product searchProduct(int id) {
		Product p=null;
		 try 
		 {
			 String url = "jdbc:oracle:thin:scott@//localhost:1521/XE";
			 
			 Connection conn=DriverManager.getConnection(url,"hr","hr");
			 PreparedStatement pstmt;
			 if (conn != null) 
			 {
				 System.out.println("Connected\n");
			 }
			 Statement stmt=conn.createStatement();
				
			 ResultSet rs=stmt.executeQuery("select * from Products where prdid="+id);
				 	
				while(rs.next())
				{
				 	p=new Product(rs.getInt(1),rs.getString(2),rs.getFloat(3));				 
				}
			
		} 
		catch (SQLException e) 
		{
				System.out.println(e.getMessage());
		}
		
		return p;
	}
	
}
