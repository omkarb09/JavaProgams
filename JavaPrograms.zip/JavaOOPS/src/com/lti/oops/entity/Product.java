package com.lti.oops.entity;

public class Product {
	String brandname;
	String barcode;
	String prodname;
	float prodcost;
	
	public Product() {
		super();
		this.brandname = "DODGE";
	}
	
	public Product( String barcode, String prodname, float prodcost) {
		
		this.brandname = "DODGE";
		this.barcode = barcode;
		this.prodname = prodname;
		this.prodcost = prodcost;
	}
	
	public float calBill(int qty)
	{
		return (this.prodcost*qty);
	}
		
	@Override
	public String toString() {
		return "Product [brandname=" + brandname + ", barcode=" + barcode + ", prodname=" + prodname + ", prodcost="
				+ prodcost + "]";
	}
	
	
	public String getBarcode() {
		return barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public String getProdname() {
		return prodname;
	}
	public void setProdname(String prodname) {
		this.prodname = prodname;
	}
	public float getProdcost() {
		return prodcost;
	}
	public void setProdcost(float prodcost) {
		this.prodcost = prodcost;
	}
	
	
	
	
}
