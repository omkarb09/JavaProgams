package com.lti.oops.entity;

public class Employee {

    public String cName;
	public int empId;
	public String empName;
	public float empSal;
	
	public Employee() {
		super();
		String cName="LTI";
	}	

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public float getEmpSal() {
		return empSal;
	}

	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}

	public Employee( int empId, String empName, float empSal) {
		super();
		String cName="LTI";
		this.cName = cName;
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
	}
	
	
	
	
	
}
