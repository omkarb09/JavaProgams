package com.lti.oops.user;

class FaceBook{
	int id;
	int n=0;
	static int likes=0;
	
	FaceBook(int id)
	{
		this.id=id;
	}
	void show()
	{
		n++;
		System.out.print("user ID: "+id+"\t");
		System.out.println("n :"+n);
	}
	
	static void p_like()
	{
		likes++;
		System.out.println("likes :"+likes);
	}
}

public class MyFacebook {
	public static void main(String[] args) {
		FaceBook u1=new FaceBook(101);
		u1.show();
		FaceBook.p_like();
		
		FaceBook u2=new FaceBook(102);
		u2.show();
		FaceBook.p_like();
		
		FaceBook u3=new FaceBook(103);
		u3.show();
		FaceBook.p_like();
	}
}
