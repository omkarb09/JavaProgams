package com.lti.oops.user;

import com.lti.oops.entity.Employee;

public class UserApp {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Employee e1= new Employee(101,"Jay",5000.00f);
      
      System.out.println(e1);
      
     Employee e2 = new Employee();
      e2.setEmpId(102);
      e2.setEmpName("Vijay");
      e2.setEmpSal(6000.00f);
      System.out.println(e2);
	}

}
