package com.lti.oops.user;

import java.util.Scanner;

import com.lti.oops.entity.Product;

public class User {
	public static void main(String[] args) {
		String barcode;
		String prodname;
		float prodcost;
		float bill;
		
		Scanner sc = new Scanner(System.in);
		
		//For object 1 by getset
		Product obj1 = new Product();
		System.out.println("Enter info for Car 1\nEnter barcode:");
		barcode = sc.next();
		System.out.println("Enter product name:");
		prodname = sc.next();
		System.out.println("Enter cost:");
		prodcost = sc.nextFloat();
		
		obj1.setBarcode(barcode);
		obj1.setProdname(prodname);
		obj1.setProdcost(prodcost);
		
		System.out.println("Enter quantity:");
		bill=obj1.calBill(sc.nextInt());
		
		System.out.println(obj1+"\nBill:"+bill);
		
		//-----------------------------------------------------------------------------------------
		
		//For object 2 by constructor
		System.out.println("\n\nEnter info for Car 2\nEnter barcode:");
		barcode = sc.next();
		System.out.println("Enter product name:");
		prodname = sc.next();
		System.out.println("Enter cost:");
		prodcost = sc.nextFloat();
		
		Product obj2 = new Product(barcode,prodname,prodcost);
		
		System.out.println("Enter quantity:");
		bill=obj2.calBill(sc.nextInt());
		
		System.out.println(obj2+"\nBill:"+bill);
	}
}
