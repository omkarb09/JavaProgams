package com.lti.oops.user;

import com.lti.oops.entity.Employee;

public class UserProdApp {
  public static void main(String[] args) {
	Employee e1=new Employee(101,"jay",50000.00f);
	System.out.println(e1);
	
	
	Employee e2=new Employee(102,"vijay",60000.00f);
	System.out.println(e2);
}
}
