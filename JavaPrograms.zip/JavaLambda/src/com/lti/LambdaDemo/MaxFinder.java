package com.lti.LambdaDemo;

public interface MaxFinder 
{
public double maximum(double num1,double num2);

}
