package com.lti.exceptiondemo;

/* Program to Demonstrates 'Own exception' */


class OwnException extends Exception
{
	private int no;	
	OwnException(int no1)
	{
		no=no1;
	}
	public String toString()
	
	{
		return "ownException Odd Number("+no+")";
	}
}
public class Exception9{
	 static void evenodd(int number) throws OwnException
	{
		System.out.println("n called evenodd ("+number+")");
		
		if(number%2==0)
					System.out.println("Normal Exit....Number is Even ");
		else
			throw new OwnException(number); 
	}		
	 
	public static void main(String args[]) 
	{			
				try 
				{
					evenodd(23);
				}
				catch (OwnException e)
				{
					System.out.println(e);
				}
			
	}
}
					
		
