package com.lti.exceptiondemo;

public class Checked_Unchecked_Exp {
	public static void main(String[] args) 
	{
		int k=1000;
		try
		{
			int i = 0;
			int j =500/i;
			System.out.println(" j " +j);
		}
		catch (ArithmeticException e) 
		{
			System.out.println("Please check u r dividing by zero");
			e.printStackTrace();
		}
		
		
		System.out.println("K:" + k);
	}
}
