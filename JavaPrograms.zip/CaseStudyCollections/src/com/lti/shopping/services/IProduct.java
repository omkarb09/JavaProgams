package com.lti.shopping.services;

import java.util.List;

import com.lti.shopping.entity.Product;

public interface IProduct {
	List addProduct(Product p);
}
