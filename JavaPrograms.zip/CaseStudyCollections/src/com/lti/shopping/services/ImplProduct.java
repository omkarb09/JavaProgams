package com.lti.shopping.services;

import java.util.ArrayList;
import java.util.List;

import com.lti.shopping.entity.Product;

public class ImplProduct implements IProduct {
	
	static List mylist = new ArrayList();
	
	public List addProduct(Product p)
	{
		
		mylist.add(p);
		
		return mylist;
		
	}
}
