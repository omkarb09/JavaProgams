package com.lti.shopping.user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.lti.shopping.entity.Product;
import com.lti.shopping.services.IProduct;
import com.lti.shopping.services.ImplProduct;

public class UserApp {
	public static void main(String[] args) {
	
	List mylist=new ArrayList();
	Scanner sc = new Scanner(System.in);
	String ans;
	int no;
	do {
		System.out.println("***** DMART Products Services ****");
		System.out.println("1.Add product ");
		System.out.println("2.Display all product ");
		System.out.println("Pls enter your choice: ");
		no = sc.nextInt();

		switch (no) {
		case 1:
				String ch;
				do
				{
					System.out.println("case1 ");
					
					System.out.println("Enter id:");
					int id=sc.nextInt();
					
					System.out.println("Enter Product Name:");
					String nm=sc.next();
					
					System.out.println("Enter product cost:");
					float cost=sc.nextFloat();
					
					Product p = new Product(id,nm,cost);
					
					IProduct service = new ImplProduct();
					mylist=service.addProduct(p);
					
					
					System.out.println("Add another product?");
					ch = sc.next();
				}while(ch.equals("Yes")||ch.equals("Y")||ch.equals("y"));
				
				
				break;
		case 2: System.out.println("case 2");
				
				
				Iterator it1 = mylist.iterator();
				
				while(it1.hasNext())
				{
					System.out.println(it1.next());
				}
				break;
		default:System.out.println("Enter proper choice");
				break;
		}
		System.out.println("Do you want to continue yes/no");
		ans = sc.next();
	} while (ans.equals("Yes") || ans.equals("y") || ans.equals("yes"));
}
}
