package com.lti.miniproject;

public class Complaint {
	String dateReceived;
	String product;
	String subProduct;
	String issue;
	String subIssue;
	String company;
	String state;
	String zipcode;
	String submitted;
	String dateSent;
	String companyResponse;
	String timelyResponse;
	String comsumerDisputed;
	String complaintId;
	public Complaint() {
		super();
	}
	public Complaint(String dateReceived, String product, String subProduct, String issue, String subIssue,
			String company, String state, String zipcode, String submitted, String dateSent, String companyResponse,
			String timelyResponse, String comsumerDisputed, String complaintId) {
		super();
		this.dateReceived = dateReceived;
		this.product = product;
		this.subProduct = subProduct;
		this.issue = issue;
		this.subIssue = subIssue;
		this.company = company;
		this.state = state;
		this.zipcode = zipcode;
		this.submitted = submitted;
		this.dateSent = dateSent;
		this.companyResponse = companyResponse;
		this.timelyResponse = timelyResponse;
		this.comsumerDisputed = comsumerDisputed;
		this.complaintId = complaintId;
	}
	public String getDateReceived() {
		return dateReceived;
	}
	public void setDateReceived(String dateReceived) {
		this.dateReceived = dateReceived;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getSubProduct() {
		return subProduct;
	}
	public void setSubProduct(String subProduct) {
		this.subProduct = subProduct;
	}
	public String getIssue() {
		return issue;
	}
	public void setIssue(String issue) {
		this.issue = issue;
	}
	public String getSubIssue() {
		return subIssue;
	}
	public void setSubIssue(String subIssue) {
		this.subIssue = subIssue;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getSubmitted() {
		return submitted;
	}
	public void setSubmitted(String submitted) {
		this.submitted = submitted;
	}
	public String getDateSent() {
		return dateSent;
	}
	public void setDateSent(String dateSent) {
		this.dateSent = dateSent;
	}
	public String getCompanyResponse() {
		return companyResponse;
	}
	public void setCompanyResponse(String companyResponse) {
		this.companyResponse = companyResponse;
	}
	public String getTimelyResponse() {
		return timelyResponse;
	}
	public void setTimelyResponse(String timelyResponse) {
		this.timelyResponse = timelyResponse;
	}
	public String getComsumerDisputed() {
		return comsumerDisputed;
	}
	public void setComsumerDisputed(String comsumerDisputed) {
		this.comsumerDisputed = comsumerDisputed;
	}
	public String getComplaintId() {
		return complaintId;
	}
	public void setComplaintId(String complaintId) {
		this.complaintId = complaintId;
	}
	@Override
	public String toString() {
		return "dateReceived=" + dateReceived + "\nproduct=" + product + "\nsubProduct=" + subProduct
				+ "\nissue=" + issue + "\nsubIssue=" + subIssue + "\ncompany=" + company + "\nstate=" + state
				+ "\nzipcode=" + zipcode + "\nsubmitted=" + submitted + "\ndateSent=" + dateSent + "\ncompanyResponse="
				+ companyResponse + "\ntimelyResponse=" + timelyResponse + "\ncomsumerDisputed=" + comsumerDisputed
				+ "\ncomplaintId=" + complaintId + "\n";
	}
	
	
}
