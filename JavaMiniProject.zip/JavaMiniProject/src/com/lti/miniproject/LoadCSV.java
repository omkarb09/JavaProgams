package com.lti.miniproject;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;

import com.opencsv.CSVReader;

public class LoadCSV {
	
	public ArrayList<Complaint> loadFile()
	{
		CSVReader reader = null;  
		String[] arr=new String[14];
		Complaint obj;
		ArrayList<Complaint> mylist=new ArrayList<>();		
		try  
		{  
		//parsing a CSV file into CSVReader class constructor  
		reader = new CSVReader(new FileReader("C:\\Users\\AW204_PC14\\Desktop\\complaints.csv"));  
		String [] nextLine;  
		//reads one line at a time  
		reader.readNext();
			while ((nextLine = reader.readNext()) != null)  
			{  
				int i=0;
				for(String token : nextLine)  
				{  
					//System.out.print(token+"\t");  
					arr[i]=token;
					i++;
				}   
				obj=new Complaint(arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6],arr[7],arr[8],arr[9],arr[10],arr[11],arr[12],arr[13]);
				mylist.add(obj);
			}  
		}  
		catch (Exception e)   
		{  
		e.printStackTrace();  
		}  
		return mylist;
	}
	/*public static void main(String[] args) {
		CSVReader reader = null;  
		String[] arr=new String[14];
		Complaint obj;
		ArrayList<Complaint> mylist=new ArrayList<>();		
		try  
		{  
		//parsing a CSV file into CSVReader class constructor  
		reader = new CSVReader(new FileReader("C:\\Users\\AW204_PC14\\Desktop\\temp.csv"));  
		String [] nextLine;  
		//reads one line at a time  
		reader.readNext();
			while ((nextLine = reader.readNext()) != null)  
			{  
				int i=0;
				for(String token : nextLine)  
				{  
					System.out.print(token+"\t");  
					arr[i]=token;
					i++;
				}  
				System.out.print("\n");  
				obj=new Complaint(arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6],arr[7],arr[8],arr[9],arr[10],arr[11],arr[12],arr[13]);
				mylist.add(obj);
			}  
			
			Iterator it1 = mylist.iterator();
			
			while(it1.hasNext())
			{
				System.out.println(it1.next());
			}
		}  
		catch (Exception e)   
		{  
		e.printStackTrace();  
		}  
	}*/
}
