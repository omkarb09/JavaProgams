package com.lti.miniproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

public class User {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		ArrayList<Complaint> mylist=new ArrayList<>();
		LoadCSV obj=new LoadCSV();
		mylist=obj.loadFile();
		String ans;
		int no;
		do {
			System.out.println("***** Complaint Services ****");
			System.out.println("1.Add new complaint ");
			System.out.println("2.Display all complaint with timely response ");
			System.out.println("3.Display all complaint with closed/closed with explaination ");
			System.out.println("4.Display complaint with complaint Id ");
			System.out.println("5.Display complaint based on user provided by user");
			System.out.println("6.Display number of days took by bank to close complaint");
			System.out.println("7.Display all the complaints based on the name of the bank");
			System.out.println("Pls enter your choice: ");
			no = sc.nextInt();
			
			System.out.println("\n");
			switch (no) {
			case 1:
					System.out.println("Enter dateReceived:");
					String dateReceived=sc.next();
					
					System.out.println("Enter Product :");
					String product=sc.next();
					
					System.out.println("Enter Sub product :");
					String subProduct=sc.next();
					
					System.out.println("Enter issue :");
					String issue=sc.next();
					
					System.out.println("Enter subissue :");
					String subIssue=sc.next();
					
					System.out.println("Enter company :");
					String company=sc.next();
					
					System.out.println("Enter state :");
					String state=sc.next();
					
					System.out.println("Enter zipcode :");
					String zipcode=sc.next();
					
					System.out.println("Enter submitted :");
					String submitted=sc.next();
					
					System.out.println("Enter dateSent :");
					String dateSent=sc.next();
					
					System.out.println("Enter company response :");
					String companyResponse=sc.next();
					
					System.out.println("Enter timely response :");
					String timelyResponse=sc.next();
					
					System.out.println("Enter comsumer disputed :");
					String comsumerDisputed=sc.next();
					
					System.out.println("Enter complaint id :");
					String complaintId=sc.next();
					
					mylist.add(new Complaint(dateReceived,product,subProduct,issue,subIssue,company,state,zipcode,submitted,dateSent,companyResponse,timelyResponse,comsumerDisputed,complaintId));
					break;
			case 2: 				
					for(Complaint d : mylist) 
					{
					    if(d.timelyResponse.equals("Yes")) 
					    {
					        System.out.println(d); 
					    }
					}
					break;
			
			case 3:
				
		
				for(Complaint d : mylist) {
				    if(d.companyResponse.equals("Closed") ) 
				    {
				        System.out.println(d); 
				    }
				}
				for(Complaint d : mylist) {
				    if(d.companyResponse.equals("Closed with explanation")) 
				    {
				        System.out.println(d); 
				    }
				}
				
				break;
				
			case 4:
				System.out.println("Enter complaint id :");
				String id=sc.next();
				
				for(Complaint d : mylist) 
				{
				    if(d.complaintId.equals(id) ) 
				    {
				        System.out.println(d); 
				    }
				}
				break;
			
			case 5:
				System.out.println("Enter complaint year :");
				String tempYear=sc.next();
				for(Complaint d : mylist) 
				{
					 String[] arrSplit = d.dateSent.split("/");
					 String year=null;
					 for (int i=0; i < arrSplit.length; i++)
					 {
					    year=arrSplit[i];
					 }
					 if(year.equals(tempYear) ) 
					 {
						 System.out.println(d); 
					 }
					 
				}
				break;
				
			case 6:
				for(Complaint d : mylist) 
				{
					String dateStart = d.dateReceived;
					String dateStop = d.dateSent;
					long diffDays=0;
					SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

					Date d1 = null;
					Date d2 = null;

					try {
						d1 = format.parse(dateStart);
						d2 = format.parse(dateStop);

						//in milliseconds
						long diff = d2.getTime() - d1.getTime();

						diffDays = diff / (24 * 60 * 60 * 1000);

						
					}
					catch (Exception e) {
						// TODO: handle exception
					}
					
				    System.out.println("Complaint id:"+d.complaintId); 
				    System.out.println("Days to close complaint:"+diffDays); 
				    
				}
				
				
				break;
				
			case 7:
				
				InputStreamReader r=new InputStreamReader(System.in);    
			    BufferedReader br=new BufferedReader(r);            
			    System.out.println("Enter bank name");    
			    String bank=null;
				try {
					bank = br.readLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  
				
				
				for(Complaint d : mylist) 
				{
				    if(d.company.equals(bank) ) 
				    {
				        System.out.println(d); 
				    }
				}
				break;
			default:System.out.println("Enter proper choice");
					break;
			}
			System.out.println("Do you want to continue yes/no");
			ans = sc.next();
		} while (ans.equals("Yes") || ans.equals("y") || ans.equals("yes"));
	}
}
